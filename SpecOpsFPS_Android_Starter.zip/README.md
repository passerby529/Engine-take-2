# SpecOpsFPS Android Starter (ZIP)

This is a **minimal Android APK starter** you can import into **Android Studio** and build.

## What you get
- A tiny LibGDX-based 3D scene (ground + boxes)
- Touch look + simple forward/back + strafe
- Builds as an Android app (APK)

## Build APK (Android Studio)
1. Install Android Studio (use JDK 17 when prompted).
2. Open Android Studio → **Open** → select this folder:
   `SpecOpsFPS_Android_Starter`
3. If prompted:
   - Accept Gradle sync
   - Install missing SDKs (Compile SDK 34)
4. Build:
   - **Build > Build Bundle(s) / APK(s) > Build APK(s)**
5. Your APK will be at:
   `android/build/outputs/apk/debug/android-debug.apk`

## Notes
- This is just a starter. No weapon logic is included.
- You can safely rename the package `com.wordhunter.starter` later.

