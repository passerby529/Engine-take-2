\
package com.wordhunter.starter;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;

/**
 * Minimal starter: first-person-ish camera in a simple test yard.
 *
 * Controls (touch):
 * - Drag anywhere: look around
 * - Left side: hold to move forward/back by dragging up/down
 * - Right side: hold to strafe left/right by dragging left/right
 *
 * Keyboard (if you attach one):
 * - WASD: move
 * - Mouse drag: look (if supported)
 */
public class MainGame extends ApplicationAdapter {

    private PerspectiveCamera cam;
    private ModelBatch batch;
    private Environment env;

    private Model model;
    private final Array<ModelInstance> instances = new Array<>();

    // Movement state
    private float yawDeg = 0f;
    private float pitchDeg = 0f;
    private final Vector3 moveDir = new Vector3();

    // Touch state
    private int lookPointer = -1;
    private int movePointer = -1;
    private int strafePointer = -1;
    private float lastLookX, lastLookY;
    private float moveStartX, moveStartY;
    private float strafeStartX, strafeStartY;
    private float moveAxis = 0f;    // forward/back (-1..1)
    private float strafeAxis = 0f;  // left/right (-1..1)

    @Override
    public void create() {
        batch = new ModelBatch();

        cam = new PerspectiveCamera(75f, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        cam.near = 0.1f;
        cam.far = 500f;
        cam.position.set(0f, 2.0f, 8f);
        cam.lookAt(0f, 1.5f, 0f);
        cam.update();

        env = new Environment();
        env.set(new ColorAttribute(ColorAttribute.AmbientLight, 0.6f, 0.6f, 0.6f, 1f));
        env.add(new DirectionalLight().set(1f, 1f, 1f, -0.6f, -1f, -0.2f));

        ModelBuilder mb = new ModelBuilder();
        model = mb.createBox(1f, 1f, 1f,
                new com.badlogic.gdx.graphics.g3d.Material(ColorAttribute.createDiffuse(0.25f, 0.7f, 0.3f, 1f)),
                com.badlogic.gdx.graphics.VertexAttributes.Usage.Position |
                        com.badlogic.gdx.graphics.VertexAttributes.Usage.Normal);

        // Ground plane (a big flat box)
        Model ground = mb.createBox(60f, 0.2f, 60f,
                new com.badlogic.gdx.graphics.g3d.Material(ColorAttribute.createDiffuse(0.25f, 0.25f, 0.27f, 1f)),
                com.badlogic.gdx.graphics.VertexAttributes.Usage.Position |
                        com.badlogic.gdx.graphics.VertexAttributes.Usage.Normal);
        instances.add(new ModelInstance(ground, 0f, 0f, 0f));

        // Some obstacles
        for (int x = -6; x <= 6; x += 3) {
            for (int z = -6; z <= 6; z += 3) {
                if (x == 0 && z == 0) continue;
                ModelInstance box = new ModelInstance(model);
                box.transform.setToTranslation(x, 0.6f, z);
                instances.add(box);
            }
        }

        // Input
        Gdx.input.setInputProcessor(new InputAdapter() {
            @Override
            public boolean touchDown(int screenX, int screenY, int pointer, int button) {
                float w = Gdx.graphics.getWidth();
                float h = Gdx.graphics.getHeight();
                float nx = screenX / w; // 0..1
                float ny = screenY / h; // 0..1

                // Reserve left third for forward/back, right third for strafe, middle for look,
                // but look can be anywhere if not already captured.
                if (nx < 0.33f && movePointer == -1) {
                    movePointer = pointer;
                    moveStartX = screenX;
                    moveStartY = screenY;
                    return true;
                }
                if (nx > 0.66f && strafePointer == -1) {
                    strafePointer = pointer;
                    strafeStartX = screenX;
                    strafeStartY = screenY;
                    return true;
                }

                if (lookPointer == -1) {
                    lookPointer = pointer;
                    lastLookX = screenX;
                    lastLookY = screenY;
                    return true;
                }
                return false;
            }

            @Override
            public boolean touchDragged(int screenX, int screenY, int pointer) {
                if (pointer == lookPointer) {
                    float dx = screenX - lastLookX;
                    float dy = screenY - lastLookY;
                    lastLookX = screenX;
                    lastLookY = screenY;

                    float sens = 0.15f;
                    yawDeg -= dx * sens;
                    pitchDeg = MathUtils.clamp(pitchDeg - dy * sens, -75f, 75f);
                    return true;
                }
                if (pointer == movePointer) {
                    float dy = moveStartY - screenY;
                    float axis = dy / (Gdx.graphics.getHeight() * 0.25f);
                    moveAxis = MathUtils.clamp(axis, -1f, 1f);
                    return true;
                }
                if (pointer == strafePointer) {
                    float dx = screenX - strafeStartX;
                    float axis = dx / (Gdx.graphics.getWidth() * 0.25f);
                    strafeAxis = MathUtils.clamp(axis, -1f, 1f);
                    return true;
                }
                return false;
            }

            @Override
            public boolean touchUp(int screenX, int screenY, int pointer, int button) {
                if (pointer == lookPointer) {
                    lookPointer = -1;
                    return true;
                }
                if (pointer == movePointer) {
                    movePointer = -1;
                    moveAxis = 0f;
                    return true;
                }
                if (pointer == strafePointer) {
                    strafePointer = -1;
                    strafeAxis = 0f;
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    public void resize(int width, int height) {
        cam.viewportWidth = width;
        cam.viewportHeight = height;
        cam.update();
    }

    private void update(float dt) {
        float speed = 6.0f;

        // Keyboard fallback
        float kbForward = 0f;
        float kbStrafe = 0f;
        if (Gdx.input.isKeyPressed(Input.Keys.W)) kbForward += 1f;
        if (Gdx.input.isKeyPressed(Input.Keys.S)) kbForward -= 1f;
        if (Gdx.input.isKeyPressed(Input.Keys.D)) kbStrafe += 1f;
        if (Gdx.input.isKeyPressed(Input.Keys.A)) kbStrafe -= 1f;

        float forward = (Math.abs(kbForward) > 0.01f) ? kbForward : moveAxis;
        float strafe = (Math.abs(kbStrafe) > 0.01f) ? kbStrafe : strafeAxis;

        // Build direction vectors from yaw
        float yawRad = yawDeg * MathUtils.degreesToRadians;
        Vector3 fwd = new Vector3(-MathUtils.sin(yawRad), 0f, -MathUtils.cos(yawRad)).nor();
        Vector3 right = new Vector3(fwd.z, 0f, -fwd.x).nor();

        moveDir.setZero();
        moveDir.mulAdd(fwd, forward);
        moveDir.mulAdd(right, strafe);
        if (moveDir.len2() > 0.0001f) moveDir.nor().scl(speed * dt);

        cam.position.add(moveDir);

        // Apply look
        cam.direction.set(0f, 0f, -1f);
        cam.up.set(Vector3.Y);

        cam.direction.rotate(Vector3.Y, yawDeg);

        // pitch around camera right axis
        Vector3 camRight = new Vector3(cam.direction).crs(Vector3.Y).nor();
        cam.direction.rotate(camRight, pitchDeg);

        // Keep height roughly constant
        cam.position.y = 2.0f;

        cam.update();
    }

    @Override
    public void render() {
        float dt = Math.min(Gdx.graphics.getDeltaTime(), 1f / 30f);
        update(dt);

        Gdx.gl.glViewport(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        Gdx.gl.glClearColor(0.05f, 0.06f, 0.07f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);

        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST);

        batch.begin(cam);
        for (ModelInstance mi : instances) {
            batch.render(mi, env);
        }
        batch.end();
    }

    @Override
    public void dispose() {
        if (batch != null) batch.dispose();
        if (model != null) model.dispose();
        for (ModelInstance mi : instances) {
            // models disposed above
        }
    }
}
