package com.specopsfps.app;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;

public class SpecOpsGame extends Game {
    @Override
    public void create() {
        Gdx.app.log("GAME", "create() called");
    }
}