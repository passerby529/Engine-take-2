\
package com.wordhunter.starter;

import android.os.Bundle;
import android.widget.Toast;

import com.badlogic.gdx.backends.android.AndroidApplication;
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration;

public class AndroidLauncher extends AndroidApplication {
    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            AndroidApplicationConfiguration config = new AndroidApplicationConfiguration();
        config.useImmersiveMode = true;
            initialize(new MainGame(), config);
        } catch (Throwable t) {
            t.printStackTrace();
            Toast.makeText(this, "Startup crash: " + t.getClass().getSimpleName() + "\n" + String.valueOf(t.getMessage()), Toast.LENGTH_LONG).show();
        }
    }
}
