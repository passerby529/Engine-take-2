# SpecOpsFPS A (Android OpenGL Boot)
- Pure Android + OpenGL ES 3.0 continuous render loop
- Logs tag: SPECOPS_CORE
- Visible animated background (not black) + FPS logs every second

## Build
- Debug: `./gradlew :app:assembleDebug` (wrapper optional; Actions can run `gradle :app:assembleDebug`)
