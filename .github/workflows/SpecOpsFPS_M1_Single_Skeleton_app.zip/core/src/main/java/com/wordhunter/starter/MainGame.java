\
package com.wordhunter.starter;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Plane;
import com.badlogic.gdx.math.Ray;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.JsonReader;
import com.badlogic.gdx.utils.JsonValue;

public class MainGame extends ApplicationAdapter {

    private ModelBatch modelBatch;
    private SpriteBatch uiBatch;
    private BitmapFont font;
    private PerspectiveCamera cam;
    private Environment env;
    private ModelBuilder mb;

    private Model groundModel, boxModel, sandModel;

    private final Array<Entity> entities = new Array<>();
    private final Array<Particle> particles = new Array<>();

    private int lookPointer = -1, movePointer = -1, strafePointer = -1;
    private float lastLookX, lastLookY;
    private float moveStartY, strafeStartX;
    private float moveAxis = 0f, strafeAxis = 0f;
    private float yawDeg = 0f, pitchDeg = 0f;

    private float t = 0f;

    private final PlayerState player = new PlayerState();
    private final WeaponState weapon = new WeaponState();

    private final Aabb sandZone = new Aabb(new Vector3(-12f, 0f, -12f), new Vector3(-2f, 3f, -2f));

    private Coeff coeff;
    private final MissionPressure pressure = new MissionPressure();

    @Override
    public void create() {
        modelBatch = new ModelBatch();
        uiBatch = new SpriteBatch();
        font = new BitmapFont();

        mb = new ModelBuilder();

        cam = new PerspectiveCamera(75f, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        cam.near = 0.1f;
        cam.far = 700f;
        cam.position.set(0f, 2.0f, 10f);
        cam.lookAt(0f, 1.6f, 0f);
        cam.update();

        env = new Environment();
        env.set(new ColorAttribute(ColorAttribute.AmbientLight, 0.62f, 0.62f, 0.62f, 1f));
        env.add(new DirectionalLight().set(1f, 1f, 1f, -0.6f, -1f, -0.2f));

        coeff = Coeff.load(Gdx.files.classpath("data/coeff.json"));

        groundModel = mb.createBox(90f, 0.2f, 90f,
                new com.badlogic.gdx.graphics.g3d.Material(ColorAttribute.createDiffuse(0.20f, 0.20f, 0.23f, 1f)),
                com.badlogic.gdx.graphics.VertexAttributes.Usage.Position |
                        com.badlogic.gdx.graphics.VertexAttributes.Usage.Normal);

        boxModel = mb.createBox(1.2f, 1.2f, 1.2f,
                new com.badlogic.gdx.graphics.g3d.Material(ColorAttribute.createDiffuse(0.22f, 0.65f, 0.3f, 1f)),
                com.badlogic.gdx.graphics.VertexAttributes.Usage.Position |
                        com.badlogic.gdx.graphics.VertexAttributes.Usage.Normal);

        sandModel = mb.createBox(10f, 0.1f, 10f,
                new com.badlogic.gdx.graphics.g3d.Material(ColorAttribute.createDiffuse(0.55f, 0.50f, 0.30f, 1f)),
                com.badlogic.gdx.graphics.VertexAttributes.Usage.Position |
                        com.badlogic.gdx.graphics.VertexAttributes.Usage.Normal);

        entities.add(Entity.ground(new ModelInstance(groundModel, 0f, 0f, 0f)));
        entities.add(Entity.zone(new ModelInstance(sandModel, -7f, 0.05f, -7f), "sand", coeff));

        for (int x = -10; x <= 10; x += 4) {
            for (int z = -6; z <= 12; z += 4) {
                if (x == 0 && z == 0) continue;
                String mat = ((x + z) % 8 == 0) ? "steel" : "wood";
                entities.add(Entity.destructible(new ModelInstance(boxModel, x, 0.7f, z), mat, coeff));
            }
        }

        player.inVehicle = true;
        player.opticFov = 42f;

        Gdx.input.setInputProcessor(new InputAdapter() {
            @Override
            public boolean touchDown(int screenX, int screenY, int pointer, int button) {
                float w = Gdx.graphics.getWidth();
                float nx = screenX / w;

                if (nx >= 0.33f && nx <= 0.66f && lookPointer == -1) {
                    lookPointer = pointer;
                    lastLookX = screenX;
                    lastLookY = screenY;
                    player.tapStart(screenX, screenY, t);
                    return true;
                }

                if (nx < 0.33f && movePointer == -1) {
                    movePointer = pointer;
                    moveStartY = screenY;
                    return true;
                }
                if (nx > 0.66f && strafePointer == -1) {
                    strafePointer = pointer;
                    strafeStartX = screenX;
                    return true;
                }

                if (lookPointer == -1) {
                    lookPointer = pointer;
                    lastLookX = screenX;
                    lastLookY = screenY;
                    player.tapStart(screenX, screenY, t);
                    return true;
                }
                return false;
            }

            @Override
            public boolean touchDragged(int screenX, int screenY, int pointer) {
                if (pointer == lookPointer) {
                    float dx = screenX - lastLookX;
                    float dy = screenY - lastLookY;
                    lastLookX = screenX;
                    lastLookY = screenY;

                    if (Math.abs(dx) + Math.abs(dy) > 10f) player.touchWasTap = false;

                    float sens = 0.15f;
                    yawDeg -= dx * sens;
                    pitchDeg = MathUtils.clamp(pitchDeg - dy * sens, -75f, 75f);
                    return true;
                }
                if (pointer == movePointer) {
                    float dy = moveStartY - screenY;
                    float axis = dy / (Gdx.graphics.getHeight() * 0.25f);
                    moveAxis = MathUtils.clamp(axis, -1f, 1f);
                    return true;
                }
                if (pointer == strafePointer) {
                    float dx = screenX - strafeStartX;
                    float axis = dx / (Gdx.graphics.getWidth() * 0.25f);
                    strafeAxis = MathUtils.clamp(axis, -1f, 1f);
                    return true;
                }
                return false;
            }

            @Override
            public boolean touchUp(int screenX, int screenY, int pointer, int button) {
                if (pointer == lookPointer) {
                    float dt = t - player.tapStartTime;
                    float dist = Math.abs(screenX - player.tapStartX) + Math.abs(screenY - player.tapStartY);
                    if (player.touchWasTap && dt < 0.25f && dist < 18f) {
                        tryShoot();
                    }
                    lookPointer = -1;
                    return true;
                }
                if (pointer == movePointer) {
                    movePointer = -1;
                    moveAxis = 0f;
                    return true;
                }
                if (pointer == strafePointer) {
                    strafePointer = -1;
                    strafeAxis = 0f;
                    return true;
                }
                return false;
            }
        });
    }

    private void tryShoot() {
        if (player.fainted) return;

        float jamChance = weapon.jamChance(player.inSand());
        if (MathUtils.random() < jamChance) {
            weapon.jammed = true;
            weapon.lastJamT = t;
            player.recoilKick += 2.0f;
            return;
        }
        if (weapon.jammed) return;

        weapon.onFire(player.inSand());

        float recoil = weapon.recoilKick(player.fatigue);
        player.recoilKick += recoil;

        Ray ray = cam.getPickRay(Gdx.graphics.getWidth() * 0.5f, Gdx.graphics.getHeight() * 0.5f);

        Hit best = null;
        for (Entity e : entities) {
            if (!e.visible) continue;
            Hit h = e.rayHit(ray);
            if (h != null) {
                if (best == null || h.t < best.t) best = h;
            }
        }

        if (best != null) {
            spawnImpact(best.point, best.normal, best.target.materialKey);
            DamageModel.applyBallisticHit(best.target, weapon.bulletKey, coeff);
        } else {
            Plane ground = new Plane(Vector3.Y, 0f);
            Vector3 p = new Vector3();
            if (Intersector.intersectRayPlane(ray, ground, p)) {
                spawnImpact(p, Vector3.Y, "concrete");
            }
        }
    }

    private void spawnImpact(Vector3 point, Vector3 normal, String matKey) {
        float intensity = matKey.equals("sand") ? 1.8f : 1.0f;
        particles.add(new Particle(new Vector3(point), intensity, matKey));
    }

    private void explodeAt(Vector3 pos, String explosiveKey) {
        float blast = coeff.explosiveBlast(explosiveKey);
        float shake = coeff.explosiveShake(explosiveKey);

        float dist = cam.position.dst(pos);
        float atten = 1f / Math.max(1f, dist);
        player.blastShake += shake * blast * atten;

        for (Entity e : entities) {
            if (!e.destructible || !e.visible) continue;
            float d = e.center.dst(pos);
            float a = 1f / Math.max(1.5f, d);
            DamageModel.applyBlast(e, explosiveKey, a, coeff);
        }

        for (int i = 0; i < 18; i++) {
            Vector3 p = new Vector3(pos).add(MathUtils.random(-0.6f, 0.6f), MathUtils.random(0.0f, 0.4f), MathUtils.random(-0.6f, 0.6f));
            particles.add(new Particle(p, 1.4f, "concrete"));
        }
    }

    @Override
    public void resize(int width, int height) {
        cam.viewportWidth = width;
        cam.viewportHeight = height;
        cam.update();
    }

    private void update(float dt) {
        t += dt;

        player.inSand = sandZone.contains(cam.position);

        if (weapon.jammed && (t - weapon.lastJamT) > 0.7f) weapon.jammed = false;

        if (Gdx.input.isKeyJustPressed(Input.Keys.C)) weapon.clean();
        if (Gdx.input.isKeyJustPressed(Input.Keys.V)) player.inVehicle = !player.inVehicle;
        if (Gdx.input.isKeyJustPressed(Input.Keys.H)) player.hatchOpen = !player.hatchOpen;
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) player.consumeCaffeine();
        if (Gdx.input.isKeyJustPressed(Input.Keys.R)) player.applyAdrenaline();
        if (Gdx.input.isKeyJustPressed(Input.Keys.G)) explodeAt(new Vector3(cam.position).add(cam.direction.cpy().scl(6f)), "frag");
        if (Gdx.input.isKeyJustPressed(Input.Keys.E)) pressure.forceExfilNow();

        pressure.update(dt);
        if (pressure.shouldTriggerThreatEvent()) {
            Vector3 far = new Vector3(cam.position).add(MathUtils.random(-18f, 18f), 0f, MathUtils.random(-18f, 18f));
            explodeAt(far, "heavy");
        }

        if (player.hatchOpen && pressure.isHotZone()) {
            float p = 0.12f * dt;
            if (MathUtils.random() < p) {
                player.fatigue = Math.min(1.25f, player.fatigue + 0.35f);
                player.recoilKick += 6f;
                if (MathUtils.random() < 0.35f) {
                    player.fainted = true;
                    player.faintUntil = t + 2.2f;
                }
            }
        }

        float speed = player.fainted ? 0f : 6.0f;
        float kbForward = 0f, kbStrafe = 0f;
        if (Gdx.input.isKeyPressed(Input.Keys.W)) kbForward += 1f;
        if (Gdx.input.isKeyPressed(Input.Keys.S)) kbForward -= 1f;
        if (Gdx.input.isKeyPressed(Input.Keys.D)) kbStrafe += 1f;
        if (Gdx.input.isKeyPressed(Input.Keys.A)) kbStrafe -= 1f;

        float forward = (Math.abs(kbForward) > 0.01f) ? kbForward : moveAxis;
        float strafe = (Math.abs(kbStrafe) > 0.01f) ? kbStrafe : strafeAxis;

        float activity = Math.abs(forward) + Math.abs(strafe);
        float fatigueRate = (activity > 0.2f) ? 0.18f : 0.05f;
        if (player.inSand) fatigueRate *= 1.25f;
        if (player.inVehicle) fatigueRate *= 0.55f;
        if (!player.fainted) player.fatigue = MathUtils.clamp(player.fatigue + fatigueRate * dt, 0f, 1.25f);

        if (!player.fainted && player.fatigue > 1.0f) {
            float faintChance = (player.fatigue - 1.0f) * 0.45f * dt;
            if (MathUtils.random() < faintChance) {
                player.fainted = true;
                player.faintUntil = t + 2.0f;
            }
        }
        if (player.fainted && t >= player.faintUntil) {
            player.fainted = false;
            player.fatigue = 0.65f;
        }

        float yawRad = yawDeg * MathUtils.degreesToRadians;
        Vector3 fwd = new Vector3(-MathUtils.sin(yawRad), 0f, -MathUtils.cos(yawRad)).nor();
        Vector3 right = new Vector3(fwd.z, 0f, -fwd.x).nor();

        Vector3 move = new Vector3();
        move.mulAdd(fwd, forward);
        move.mulAdd(right, strafe);
        if (move.len2() > 0.0001f) move.nor().scl(speed * dt);

        cam.position.add(move);
        cam.position.y = 2.0f;

        if (player.recoilKick > 0f) {
            pitchDeg = MathUtils.clamp(pitchDeg - player.recoilKick, -75f, 75f);
            player.recoilKick = MathUtils.lerp(player.recoilKick, 0f, 0.65f);
        }

        if (player.blastShake > 0f) {
            float s = player.blastShake;
            cam.position.x += MathUtils.random(-s, s);
            cam.position.y += MathUtils.random(-s, s);
            cam.position.z += MathUtils.random(-s, s);
            player.blastShake = MathUtils.lerp(player.blastShake, 0f, 0.25f);
        }

        if (player.inVehicle) {
            float vib = 0.015f + 0.02f * MathUtils.sin(t * 18f);
            cam.position.x += MathUtils.random(-vib, vib);
            cam.position.y += MathUtils.random(-vib, vib);
            cam.position.z += MathUtils.random(-vib, vib);
            player.opticNoise = MathUtils.lerp(player.opticNoise, weapon.dirt * 0.9f, 0.02f);
        } else {
            player.opticNoise = MathUtils.lerp(player.opticNoise, 0f, 0.05f);
        }

        cam.direction.set(0f, 0f, -1f);
        cam.up.set(Vector3.Y);
        cam.direction.rotate(Vector3.Y, yawDeg);
        Vector3 camRight = new Vector3(cam.direction).crs(Vector3.Y).nor();
        cam.direction.rotate(camRight, pitchDeg);

        cam.fieldOfView = player.inVehicle ? player.opticFov : 75f;

        cam.update();

        for (int i = particles.size - 1; i >= 0; i--) {
            Particle p = particles.get(i);
            p.update(dt);
            if (p.dead()) particles.removeIndex(i);
        }
    }

    @Override
    public void render() {
        float dt = Math.min(Gdx.graphics.getDeltaTime(), 1f / 30f);
        update(dt);

        Gdx.gl.glViewport(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        Gdx.gl.glClearColor(0.05f, 0.06f, 0.07f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST);

        modelBatch.begin(cam);
        for (Entity e : entities) if (e.visible) modelBatch.render(e.instance, env);
        for (Particle p : particles) modelBatch.render(p.instance, env);
        modelBatch.end();

        uiBatch.begin();
        font.setColor(Color.WHITE);
        font.draw(uiBatch, "M1 SINGLE (Skeleton)  |  inVehicle=" + player.inVehicle + "  hatch=" + player.hatchOpen, 12, Gdx.graphics.getHeight() - 12);
        font.draw(uiBatch, "fatigue=" + fmt(player.fatigue) + "  dirt=" + fmt(weapon.dirt) + "  jam=" + weapon.jammed + "  sand=" + player.inSand, 12, Gdx.graphics.getHeight() - 34);
        font.draw(uiBatch, pressure.uiLine(), 12, Gdx.graphics.getHeight() - 56);
        if (player.inVehicle && player.opticNoise > 0.1f) {
            font.draw(uiBatch, "OPTIC: visibility degraded (" + fmt(player.opticNoise) + ")", 12, Gdx.graphics.getHeight() - 78);
        }
        uiBatch.end();
    }

    private static String fmt(float v) {
        return String.format(java.util.Locale.US, "%.2f", v);
    }

    @Override
    public void dispose() {
        if (modelBatch != null) modelBatch.dispose();
        if (uiBatch != null) uiBatch.dispose();
        if (font != null) font.dispose();
        if (groundModel != null) groundModel.dispose();
        if (boxModel != null) boxModel.dispose();
        if (sandModel != null) sandModel.dispose();
        for (Particle p : particles) p.dispose();
    }

    static class PlayerState {
        boolean inVehicle = false;
        boolean hatchOpen = false;
        boolean inSand = false;

        float fatigue = 0f;
        boolean fainted = false;
        float faintUntil = 0f;

        float recoilKick = 0f;
        float blastShake = 0f;

        float opticFov = 42f;
        float opticNoise = 0f;

        boolean touchWasTap = false;
        float tapStartX, tapStartY, tapStartTime;

        void tapStart(float x, float y, float time) {
            touchWasTap = true;
            tapStartX = x;
            tapStartY = y;
            tapStartTime = time;
        }

        boolean inSand() { return inSand; }

        void consumeCaffeine() { fatigue = MathUtils.clamp(fatigue - 0.25f, 0f, 1.25f); }
        void applyAdrenaline() { fatigue = 0f; }
    }

    static class WeaponState {
        String bulletKey = "556";
        boolean jammed = false;
        float lastJamT = 0f;

        float dirt = 0f;
        float heat = 0f;

        void onFire(boolean inSand) {
            heat = MathUtils.clamp(heat + 0.10f, 0f, 1.2f);
            float dirtGain = inSand ? 0.06f : 0.02f;
            dirt = MathUtils.clamp(dirt + dirtGain, 0f, 1.5f);
        }

        void clean() { dirt = MathUtils.clamp(dirt - 0.65f, 0f, 1.5f); }

        float jamChance(boolean inSand) {
            float base = 0.01f;
            float sandBoost = inSand ? 0.03f : 0f;
            float dirtBoost = 0.04f * MathUtils.clamp(dirt, 0f, 1.0f);
            float heatBoost = 0.02f * MathUtils.clamp(heat, 0f, 1.0f);
            heat = MathUtils.lerp(heat, 0f, 0.02f);
            return MathUtils.clamp(base + sandBoost + dirtBoost + heatBoost, 0f, 0.22f);
        }

        float recoilKick(float fatigue) { return 0.8f * (1f + fatigue * 0.35f); }
    }

    static class Coeff {
        JsonValue root;
        static Coeff load(FileHandle fh) {
            Coeff c = new Coeff();
            c.root = new JsonReader().parse(fh);
            return c;
        }
        Material material(String key) {
            JsonValue m = root.get("materials").get(key);
            return new Material(m.getFloat("ballisticDefense"), m.getFloat("blastDefense"), m.getFloat("spallBase"));
        }
        Bullet bullet(String key) {
            JsonValue b = root.get("bullets").get(key);
            return new Bullet(b.getFloat("penetration"), b.getFloat("energy"), b.getFloat("spall"), b.getFloat("recoil"));
        }
        float explosiveBlast(String key) { return root.get("explosives").get(key).getFloat("blast"); }
        float explosiveShake(String key) { return root.get("explosives").get(key).getFloat("shake"); }
        float explosiveShrapnel(String key) { return root.get("explosives").get(key).getFloat("shrapnel"); }
    }

    static class Material {
        final float ballisticDefense, blastDefense, spallBase;
        Material(float b, float bl, float s){ ballisticDefense=b; blastDefense=bl; spallBase=s; }
    }
    static class Bullet {
        final float penetration, energy, spall, recoil;
        Bullet(float p, float e, float s, float r){ penetration=p; energy=e; spall=s; recoil=r; }
    }

    static class DamageModel {
        static void applyBallisticHit(Entity target, String bulletKey, Coeff coeff) {
            if (!target.destructible || !target.visible) return;

            Bullet bullet = coeff.bullet(bulletKey);
            Material mat = target.material;

            float pPen = MathUtils.clamp((bullet.penetration / mat.ballisticDefense) * 0.65f, 0f, 0.95f);
            boolean penetrated = MathUtils.random() < pPen;

            float energyTransfer = bullet.energy * (penetrated ? 0.55f : 0.35f);

            float spallChance = MathUtils.clamp(mat.spallBase + (penetrated ? 0.08f : 0.22f) * bullet.spall, 0f, 0.95f);
            boolean spall = MathUtils.random() < spallChance;

            float dmg = energyTransfer * (penetrated ? 1.0f : 0.75f);
            if (spall) dmg *= 1.15f;

            target.hp -= dmg;
            if (target.hp <= 0f) target.visible = false;
        }

        static void applyBlast(Entity target, String explosiveKey, float atten, Coeff coeff) {
            Material mat = target.material;
            float blast = coeff.explosiveBlast(explosiveKey);
            float shrap = coeff.explosiveShrapnel(explosiveKey);

            float pDamage = MathUtils.clamp((blast / mat.blastDefense) * 0.35f * atten, 0f, 0.65f);
            if (MathUtils.random() < pDamage) {
                float dmg = (blast * 0.35f + shrap * 0.25f) * atten;
                target.hp -= dmg;
                if (target.hp <= 0f) target.visible = false;
            }
        }
    }

    static class MissionPressure {
        float time = 0f;
        boolean exfilRecommended = false;
        boolean exfilForced = false;
        float threat = 0f;

        void update(float dt) {
            time += dt;
            if (!exfilRecommended && time > 55f) exfilRecommended = true;
            if (exfilRecommended && !exfilForced) threat = MathUtils.clamp(threat + 0.010f * dt, 0f, 1.0f);
            if (time > 140f) exfilForced = true;
        }

        boolean isHotZone() { return exfilRecommended; }

        boolean shouldTriggerThreatEvent() {
            if (!exfilRecommended) return false;
            float p = (0.02f + threat * 0.10f) * Gdx.graphics.getDeltaTime();
            return MathUtils.random() < p;
        }

        void forceExfilNow() { exfilForced = true; }

        String uiLine() {
            if (!exfilRecommended) return "Exfil: not yet | time=" + fmt(time);
            if (exfilForced) return "Exfil: ACTIVE (go now) | threat=" + fmt(threat);
            return "Exfil: RECOMMENDED | delay increases risk | threat=" + fmt(threat);
        }

        private static String fmt(float v) {
            return String.format(java.util.Locale.US, "%.2f", v);
        }
    }

    static class Aabb {
        Vector3 min, max;
        Aabb(Vector3 min, Vector3 max){ this.min=min; this.max=max; }
        boolean contains(Vector3 p){
            return p.x>=min.x && p.x<=max.x && p.y>=min.y && p.y<=max.y && p.z>=min.z && p.z<=max.z;
        }
    }

    static class Hit {
        Entity target; Vector3 point; Vector3 normal; float t;
        Hit(Entity target, Vector3 point, Vector3 normal, float t){
            this.target=target; this.point=point; this.normal=normal; this.t=t;
        }
    }

    static class Entity {
        ModelInstance instance;
        boolean visible = true;

        boolean destructible = false;
        float hp = 1.0f;
        String materialKey = "concrete";
        Material material;

        final Vector3 center = new Vector3();
        final Vector3 half = new Vector3(0.6f, 0.6f, 0.6f);

        static Entity ground(ModelInstance inst){
            Entity e = new Entity();
            e.instance = inst;
            e.visible = true;
            e.destructible = false;
            e.materialKey = "concrete";
            e.material = new Material(2.0f, 1.2f, 0.08f);
            e.half.set(45f, 0.1f, 45f);
            e.center.set(0f, 0f, 0f);
            return e;
        }

        static Entity zone(ModelInstance inst, String matKey, Coeff coeff){
            Entity e = new Entity();
            e.instance = inst;
            e.visible = true;
            e.destructible = false;
            e.materialKey = matKey;
            e.material = coeff.material(matKey);
            e.half.set(5f, 0.05f, 5f);
            e.center.set(inst.transform.getTranslation(new Vector3()));
            return e;
        }

        static Entity destructible(ModelInstance inst, String matKey, Coeff coeff){
            Entity e = new Entity();
            e.instance = inst;
            e.visible = true;
            e.destructible = true;
            e.materialKey = matKey;
            e.material = coeff.material(matKey);
            e.hp = matKey.equals("steel") ? 1.6f : 1.0f;
            e.center.set(inst.transform.getTranslation(new Vector3()));
            return e;
        }

        Hit rayHit(Ray ray){
            Vector3 c = center;
            Vector3 min = new Vector3(c.x - half.x, c.y - half.y, c.z - half.z);
            Vector3 max = new Vector3(c.x + half.x, c.y + half.y, c.z + half.z);

            float tmin = (min.x - ray.origin.x) / (ray.direction.x == 0 ? 1e-6f : ray.direction.x);
            float tmax = (max.x - ray.origin.x) / (ray.direction.x == 0 ? 1e-6f : ray.direction.x);
            if (tmin > tmax) { float tmp=tmin; tmin=tmax; tmax=tmp; }

            float tymin = (min.y - ray.origin.y) / (ray.direction.y == 0 ? 1e-6f : ray.direction.y);
            float tymax = (max.y - ray.origin.y) / (ray.direction.y == 0 ? 1e-6f : ray.direction.y);
            if (tymin > tymax) { float tmp=tymin; tymin=tymax; tymax=tmp; }

            if ((tmin > tymax) || (tymin > tmax)) return null;
            if (tymin > tmin) tmin = tymin;
            if (tymax < tmax) tmax = tymax;

            float tzmin = (min.z - ray.origin.z) / (ray.direction.z == 0 ? 1e-6f : ray.direction.z);
            float tzmax = (max.z - ray.origin.z) / (ray.direction.z == 0 ? 1e-6f : ray.direction.z);
            if (tzmin > tzmax) { float tmp=tzmin; tzmin=tzmax; tzmax=tmp; }

            if ((tmin > tzmax) || (tzmin > tmax)) return null;
            if (tzmin > tmin) tmin = tzmin;
            if (tzmax < tmax) tmax = tzmax;

            if (tmin < 0f) return null;

            Vector3 hitPoint = new Vector3(ray.origin).mulAdd(ray.direction, tmin);
            Vector3 n = new Vector3();
            float dx = Math.min(Math.abs(hitPoint.x - min.x), Math.abs(hitPoint.x - max.x));
            float dy = Math.min(Math.abs(hitPoint.y - min.y), Math.abs(hitPoint.y - max.y));
            float dz = Math.min(Math.abs(hitPoint.z - min.z), Math.abs(hitPoint.z - max.z));
            if (dx <= dy && dx <= dz) n.set(Math.signum(hitPoint.x - c.x), 0f, 0f);
            else if (dy <= dx && dy <= dz) n.set(0f, Math.signum(hitPoint.y - c.y), 0f);
            else n.set(0f, 0f, Math.signum(hitPoint.z - c.z));

            return new Hit(this, hitPoint, n, tmin);
        }
    }

    static class Particle {
        ModelInstance instance;
        private float life = 0.35f;
        private float age = 0f;
        private final Model model;

        Particle(Vector3 pos, float intensity, String matKey){
            float s = 0.08f * intensity;
            float r = matKey.equals("sand") ? 0.55f : 0.75f;
            float g = matKey.equals("sand") ? 0.50f : 0.75f;
            float b = matKey.equals("sand") ? 0.30f : 0.78f;

            ModelBuilder mb = new ModelBuilder();
            model = mb.createBox(s, s, s,
                    new com.badlogic.gdx.graphics.g3d.Material(ColorAttribute.createDiffuse(r, g, b, 1f)),
                    com.badlogic.gdx.graphics.VertexAttributes.Usage.Position |
                            com.badlogic.gdx.graphics.VertexAttributes.Usage.Normal);

            instance = new ModelInstance(model, pos);
        }

        void update(float dt){
            age += dt;
            instance.transform.trn(0f, 0.25f * dt, 0f);
        }

        boolean dead(){ return age >= life; }
        void dispose(){ model.dispose(); }
    }
}
