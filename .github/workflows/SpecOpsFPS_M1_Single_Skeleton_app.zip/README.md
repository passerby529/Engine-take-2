# SpecOps M1 Single Skeleton (ZIP) — app-module (fixed)

This ZIP matches standard Android builds (app/ module) so your GitHub Actions workflow won't look for a missing app manifest.

## Included (Single-player skeleton)
- Tap-to-shoot raycast
- Probabilistic weapon jam; higher in sand zone + dirt buildup
- Clean action reduces dirt (game mechanic)
- Coefficients loaded from core/resources/data/coeff.json:
  - ballisticDefense vs blastDefense separated
  - penetration / energy / spall simplified
- Destructible props
- Explosive blast coefficient -> distance-based camera shake (demo key G)
- Fatigue accumulation affects recoil; can faint probabilistically
- Caffeine (SPACE) & Adrenaline (R) demo
- "BMPT driver optic mode" approximation (toggle V): narrowed FOV + optic degradation indicator
- Exfil pressure logic: after ~55s exfil recommended; delay increases threat events (probabilistic)

## Build
Android Studio:
- Open folder
- Build APK
Output:
app/build/outputs/apk/debug/app-debug.apk

GitHub Actions:
- Put the ZIP at repo root
- Run your workflow (:app:assembleDebug)

## Controls
Touch:
- Drag: look
- Left third: forward/back
- Right third: strafe
- Tap (center): shoot

Keyboard (optional):
- C clean
- G grenade demo
- V vehicle toggle
- H hatch toggle
- SPACE caffeine
- R adrenaline
- E force exfil now (skeleton)

Note:
- No real-world instructions for weapons/explosives are included.
