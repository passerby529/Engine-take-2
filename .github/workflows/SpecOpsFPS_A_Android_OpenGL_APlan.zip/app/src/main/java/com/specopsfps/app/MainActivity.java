package com.specopsfps.app;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private static final String TAG = "SPECOPS_CORE";
    private SpecOpsGLSurfaceView glView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        glView = new SpecOpsGLSurfaceView(this);
        setContentView(glView);

        Log.i(TAG, "MainActivity onCreate()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (glView != null) glView.onResume();
        Log.i(TAG, "MainActivity onResume()");
    }

    @Override
    protected void onPause() {
        if (glView != null) glView.onPause();
        Log.i(TAG, "MainActivity onPause()");
        super.onPause();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE) {
            Log.i(TAG, "Touch x=" + event.getX() + " y=" + event.getY());
        }
        return true;
    }
}
