package com.specopsfps.app;

import android.content.Context;
import android.opengl.GLSurfaceView;

public class SpecOpsGLSurfaceView extends GLSurfaceView {

    public SpecOpsGLSurfaceView(Context context) {
        super(context);

        // Request OpenGL ES 3.0
        setEGLContextClientVersion(3);

        SpecOpsRenderer renderer = new SpecOpsRenderer();
        setRenderer(renderer);

        // Continuous render loop (keeps app 'alive' with visible frames)
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }
}
