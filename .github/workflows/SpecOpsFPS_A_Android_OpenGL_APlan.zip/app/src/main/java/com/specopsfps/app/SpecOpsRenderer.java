package com.specopsfps.app;

import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.util.Log;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class SpecOpsRenderer implements GLSurfaceView.Renderer {
    private static final String TAG = "SPECOPS_CORE";

    private long lastFpsTimeNs = 0L;
    private int frames = 0;
    private float t = 0f;

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        Log.i(TAG, "Renderer onSurfaceCreated()");
        Log.i(TAG, "GL_VENDOR=" + GLES30.glGetString(GLES30.GL_VENDOR));
        Log.i(TAG, "GL_RENDERER=" + GLES30.glGetString(GLES30.GL_RENDERER));
        Log.i(TAG, "GL_VERSION=" + GLES30.glGetString(GLES30.GL_VERSION));

        lastFpsTimeNs = System.nanoTime();
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        Log.i(TAG, "Renderer onSurfaceChanged() w=" + width + " h=" + height);
        GLES30.glViewport(0, 0, width, height);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        // Animate clear color so you can see it's not "frozen black"
        t += 0.01f;
        float r = 0.1f + 0.1f * (float)Math.sin(t);
        float g = 0.1f + 0.1f * (float)Math.sin(t + 2.0);
        float b = 0.1f + 0.1f * (float)Math.sin(t + 4.0);

        GLES30.glClearColor(r, g, b, 1f);
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);

        frames++;
        long now = System.nanoTime();
        if (now - lastFpsTimeNs >= 1_000_000_000L) {
            Log.i(TAG, "FPS=" + frames);
            frames = 0;
            lastFpsTimeNs = now;
        }
    }
}
